# NEXUS CORE v2

Tek dosya, sıfır bağımlılık — Claude · OpenAI · Gemini · Groq için modern yapay zekâ sohbet uygulaması.

![Python](https://img.shields.io/badge/Python-3.9%2B-blue?logo=python&logoColor=white)
![License](https://img.shields.io/badge/Lisans-MIT-green)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey)

---

## Özellikler

- **4 sağlayıcı** — Claude (Anthropic), OpenAI, Gemini (Google), Groq tek arayüzde
- **Sıfır pip kurulumu** — yalnızca Python standart kütüphanesi kullanılır
- **Akışlı yanıtlar** — kelime kelime akar, ilk token süresi gösterilir
- **Dosya ekleyebilirsin** — fotoğraf, video, PDF, kod dosyası (sürükle-bırak / yapıştır)
- **Markdown render** — başlıklar, kalın/italik, kod blokları (kopyala butonu), tablolar, listeler
- **Koyu / açık tema** — sağlayıcıya göre renk paleti değişir
- **Güvenli anahtar yönetimi** — anahtarlar yalnızca `~/.nexus/config.json` içinde yerel saklanır
- **Hata açıklamaları Türkçe** — 401, 429, 404 gibi hatalar okunabilir mesaja çevrilir
- **EXE haline getirilebilir** — Windows için `build.bat` hazır

---

## Kurulum ve Çalıştırma

### Gereksinim

- Python **3.9** veya üstü  
- pip, PyInstaller, harici paket gerekmez

```bash
python nexus.py
```

> Edge veya Chrome yoksa varsayılan tarayıcıda açılır.  
> Pencereyi kapatınca program da kapanır.

### İlk kullanım

1. Ayarlar paneli otomatik açılır.  
2. En az bir sağlayıcının API anahtarını yapıştır → **Kaydet & test et** butonuna bas.  
3. Anahtar doğrulanır ve güncel model listesi çekilir.

---

## EXE Oluşturma (Windows)

```bat
build.bat
```

Çıktı: `dist\NEXUS_CORE.exe` — tek dosya, Python kurulumu gerekmez.

> macOS / Linux için:
> ```bash
> pip install pyinstaller
> pyinstaller --onefile --noconsole --name NEXUS_CORE nexus.py
> ```

---

## API Anahtarları Nereden Alınır?

| Sağlayıcı | Kayıt |
|-----------|-------|
| Claude (Anthropic) | <https://console.anthropic.com/settings/keys> |
| OpenAI | <https://platform.openai.com/api-keys> |
| Gemini (Google) | <https://aistudio.google.com/apikey> |
| Groq | <https://console.groq.com/keys> |

---

## Dosya Ekleri

| Tür | Claude | OpenAI | Gemini | Groq |
|-----|--------|--------|--------|------|
| Görsel (PNG/JPEG/WEBP/GIF) | ✅ | ✅ | ✅ | ✅* |
| Video | ✅ (kare) | ✅ (kare) | ✅ (ham video) | ✅ (kare) |
| PDF | ✅ | ❌ | ✅ | ❌ |
| Kod / metin dosyası | ✅ | ✅ | ✅ | ✅ |

> \* Groq için vision destekli model seçili olmalı (ör. `llama-3.2-90b-vision`)

---

## Proje Yapısı

```
NEXUS_CORE/
├── nexus.py        # Tüm uygulama (backend + arayüz)
├── build.bat       # Windows EXE oluşturucu
├── .gitignore
└── README.md
```

Veriler `~/.nexus/` klasöründe saklanır (config, sohbet geçmişi, log).

---

## Güvenlik Notu

API anahtarları `~/.nexus/config.json` içinde düz metin olarak durur.  
Bu dosyayı asla GitHub'a yükleme — `.gitignore` zaten korur.

---

## Lisans

MIT — dilediğin gibi kullanabilir, değiştirebilir, dağıtabilirsin.

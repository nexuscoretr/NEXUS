@echo off
chcp 65001 >nul
echo NEXUS CORE exe olusturuluyor...
python -m pip install --upgrade pyinstaller
python -m PyInstaller --onefile --noconsole --name NEXUS_CORE nexus.py
echo.
echo Bitti: dist\NEXUS_CORE.exe
pause

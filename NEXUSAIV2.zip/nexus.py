#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NEXUS CORE v2 — Claude · OpenAI · Gemini · Groq tek uygulamada.

* Sadece Python standart kütüphanesi kullanır (pip install GEREKMEZ).
* Arayüz yerel bir web sayfasıdır; Edge/Chrome "uygulama penceresi" olarak açılır.
* Pencere kapanınca program kendiliğinden kapanır.

Çalıştır:   python nexus.py
EXE yap:    pyinstaller --onefile --noconsole --name NEXUS_CORE nexus.py
"""
import http.client
import json
import os
import re
import secrets
import select
import socket
import ssl
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

VERSION = "2.0"
UA = f"NexusCore/{VERSION}"          # Groq/Cloudflare varsayılan Python UA'sını engelleyebilir
DATA = Path(os.environ.get("NEXUS_HOME") or Path.home() / ".nexus")
DATA.mkdir(parents=True, exist_ok=True)
CFG_FILE, CHAT_FILE, LOG_FILE = DATA / "config.json", DATA / "chats.json", DATA / "nexus.log"
TOKEN = secrets.token_urlsafe(24)    # her açılışta yeni; yabancı sitelerin yerel API'yi çağırmasını engeller
LOCK = threading.Lock()
MAX_BODY = 80 * 1024 * 1024
LIFE = {"seen": False, "last": time.time(), "bye": 0.0}


def log(*a):
    try:
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > 1_000_000:
            LOG_FILE.unlink()
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + " ".join(map(str, a)) + "\n")
    except Exception:
        pass


# ───────────────────────── Sağlayıcılar ─────────────────────────
PROV = {
    "anthropic": dict(
        name="Claude", host="api.anthropic.com", env=("ANTHROPIC_API_KEY",),
        url="https://console.anthropic.com/settings/keys",
        fallback=["claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5"],
        prefer=[r"sonnet"]),
    "openai": dict(
        name="OpenAI", host="api.openai.com", env=("OPENAI_API_KEY",),
        url="https://platform.openai.com/api-keys",
        fallback=["gpt-5", "gpt-5-mini", "gpt-4o", "gpt-4o-mini"],
        prefer=[r"^gpt-\d+(\.\d+)?$", r"^gpt-4o$"]),
    "gemini": dict(
        name="Gemini", host="generativelanguage.googleapis.com", env=("GEMINI_API_KEY", "GOOGLE_API_KEY"),
        url="https://aistudio.google.com/apikey",
        fallback=["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite"],
        prefer=[r"flash(?!-lite)", r"pro"]),
    "groq": dict(
        name="Groq", host="api.groq.com", env=("GROQ_API_KEY",),
        url="https://console.groq.com/keys",
        fallback=["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-120b", "openai/gpt-oss-20b"],
        prefer=[r"llama-3\.3-70b", r"llama"]),
}


class ApiError(Exception):
    def __init__(self, msg, code=""):
        super().__init__(msg)
        self.code = code


def pick_default(pid, ids):
    for pat in PROV[pid]["prefer"]:
        for i in ids:
            if re.search(pat, i):
                return i
    return ids[0] if ids else ""


# ───────────────────────── Ayarlar & anahtarlar ─────────────────────────
DEF = {"provider": "anthropic", "keys": {}, "models": {}, "model": {}, "system": "", "temp": 0.7, "theme": "dark"}


def load_cfg():
    try:
        c = json.loads(CFG_FILE.read_text("utf-8"))
    except Exception:
        c = {}
    if not isinstance(c, dict):
        c = {}
    for k, v in DEF.items():
        c.setdefault(k, {} if isinstance(v, dict) else v)
    return c


def save_json(path, obj):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False), "utf-8")
    os.replace(tmp, path)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def update_cfg(fn):
    with LOCK:
        c = load_cfg()
        fn(c)
        save_json(CFG_FILE, c)


def clean_key(k):
    """Kopyala-yapıştırdan gelen çöpü temizler: boşluk, satır sonu, tırnak, 'Bearer '."""
    k = (k or "").strip().strip("\"'`")
    k = re.sub(r"^(authorization:?\s*)?bearer\s+", "", k, flags=re.I)
    return re.sub(r"\s+", "", k)


def guess_provider(k):
    if k.startswith("sk-ant-"):
        return "anthropic"
    if k.startswith("gsk_"):
        return "groq"
    if k.startswith("AIza"):
        return "gemini"
    if k.startswith("sk-"):
        return "openai"
    return None


def get_key(pid, cfg=None):
    cfg = cfg or load_cfg()
    k = clean_key(cfg["keys"].get(pid, ""))
    if not k:
        for e in PROV[pid]["env"]:
            k = clean_key(os.environ.get(e, ""))
            if k:
                break
    return k


def mask(k):
    return "" if not k else (k[:6] + "…" + k[-4:] if len(k) > 14 else "••••••")


def state():
    cfg, out = load_cfg(), {}
    for pid, P in PROV.items():
        key = get_key(pid, cfg)
        models = cfg["models"].get(pid) or [{"id": m, "label": m} for m in P["fallback"]]
        ids = [m["id"] for m in models]
        cur = cfg["model"].get(pid)
        if cur not in ids:
            cur = pick_default(pid, ids)
        out[pid] = {"name": P["name"], "hasKey": bool(key), "masked": mask(key), "models": models,
                    "model": cur, "url": P["url"], "live": pid in cfg["models"]}
    prov = cfg["provider"] if cfg["provider"] in PROV else "anthropic"
    return {"providers": out, "settings": {"provider": prov, "system": cfg["system"],
                                           "temp": cfg["temp"], "theme": cfg["theme"]}}


# ───────────────────────── HTTP katmanı (bağlantı havuzlu = hızlı) ─────────────────────────
CTX = ssl.create_default_context()   # Windows'ta sistem sertifika deposunu kullanır (certifi gerekmez)
_POOL, _PL = {}, threading.Lock()


def _new_conn(host):
    return http.client.HTTPSConnection(host, timeout=180, context=CTX)


def _take(host):
    with _PL:
        lst = _POOL.get(host)
        if lst:
            return lst.pop(), True
    return _new_conn(host), False


def _give(host, conn, resp):
    """Yanıt bittiyse bağlantıyı havuza koy → sonraki istekte TLS el sıkışması yok."""
    try:
        if resp is not None and not resp.isclosed():
            resp.read()
        if resp is not None and resp.isclosed() and not resp.will_close:
            with _PL:
                lst = _POOL.setdefault(host, [])
                if len(lst) < 4:
                    lst.append(conn)
                    return
    except Exception:
        pass
    try:
        conn.close()
    except Exception:
        pass


def call(host, method, path, headers, body=None):
    data = None if body is None else json.dumps(body, ensure_ascii=False).encode("utf-8")
    hdr = {"User-Agent": UA, "Accept": "*/*", **headers}
    if data is not None:
        hdr["Content-Type"] = "application/json"
    for _ in range(2):
        conn, reused = _take(host)
        try:
            conn.request(method, path, data, hdr)
            return conn.getresponse(), conn
        except (http.client.RemoteDisconnected, http.client.CannotSendRequest, http.client.ResponseNotReady,
                BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            conn.close()
            if reused:
                continue          # havuzdaki bayat bağlantı → yenisiyle tekrar dene
            break
        except ssl.SSLCertVerificationError as e:
            conn.close()
            raise ApiError("SSL sertifikası doğrulanamadı. Antivirüs / VPN / şirket proxy'si HTTPS trafiğini "
                           "tarıyor olabilir.\n" + str(e))
        except OSError as e:
            conn.close()
            raise ApiError(f"{host} sunucusuna bağlanılamadı ({e.__class__.__name__}). "
                           "İnternet, VPN veya güvenlik duvarını kontrol et.")
    raise ApiError("Bağlantı koptu, tekrar dene.")


HINT = {
    400: "İstek reddedildi.",
    401: "API anahtarı geçersiz ya da süresi dolmuş. Ayarlar'dan anahtarı yeniden yapıştır.",
    403: "Erişim reddedildi: anahtar yetkisi, ülke/bölge kısıtı ya da model izni sorunu olabilir.",
    404: "Model bulunamadı. Model listesini yenile (↻) ve başka bir model seç.",
    413: "İstek çok büyük (ek dosya / video fazla büyük olabilir).",
    429: "Hız limiti ya da kota/bakiye doldu. Biraz bekle veya faturalandırmayı kontrol et.",
    529: "Servis şu an aşırı yüklü, birazdan tekrar dene.",
}


def err_text(raw):
    try:
        j = json.loads(raw)
        e = j.get("error", j) if isinstance(j, dict) else j
        if isinstance(e, list) and e:
            e = e[0].get("error", e[0])
        if isinstance(e, dict):
            return e.get("message") or json.dumps(e, ensure_ascii=False)
        return str(e)
    except Exception:
        return (raw.decode("utf-8", "replace") if isinstance(raw, bytes) else str(raw))[:400]


def http_error(status, raw, pid):
    hint = HINT.get(status) or (f"{PROV[pid]['name']} sunucu hatası, tekrar dene." if status >= 500 else f"HTTP {status}")
    code = "auth" if status in (401, 403) else "model" if status == 404 else "limit" if status == 429 else ""
    return ApiError(f"{hint}\n\nSağlayıcı mesajı: {err_text(raw)}", code)


def auth_headers(pid, key):
    if pid == "anthropic":
        return {"x-api-key": key, "anthropic-version": "2023-06-01"}
    if pid == "gemini":
        return {"x-goog-api-key": key}
    return {"Authorization": "Bearer " + key}


def fetch_models(pid, key):
    """Anahtarı test eder VE gerçek model listesini çeker (model adı eskimesi sorununu bitirir)."""
    P = PROV[pid]
    path = {"anthropic": "/v1/models?limit=100", "openai": "/v1/models",
            "groq": "/openai/v1/models", "gemini": "/v1beta/models?pageSize=200"}[pid]
    resp, conn = call(P["host"], "GET", path, auth_headers(pid, key))
    try:
        raw, status = resp.read(), resp.status
    except Exception:
        conn.close()
        raise ApiError("Model listesi okunamadı (bağlantı koptu).")
    if status >= 400:
        conn.close()
        raise http_error(status, raw, pid)
    _give(P["host"], conn, resp)
    j = json.loads(raw)
    if pid == "anthropic":
        ms = [(m["id"], m.get("display_name") or m["id"]) for m in j.get("data", [])]
    elif pid == "gemini":
        ms = []
        for m in j.get("models", []):
            n = m.get("name", "").replace("models/", "")
            if ("generateContent" in m.get("supportedGenerationMethods", []) and n.startswith("gemini")
                    and not re.search(r"tts|image|embed|live|audio|robotics|computer|aqa", n)):
                ms.append((n, m.get("displayName") or n))
        ms.sort(key=lambda x: x[0], reverse=True)
    else:
        bad = (r"whisper|tts|guard|embed|moderation|audio|realtime|transcribe|image|dall|sora|search|davinci|"
               r"babbage|instruct|orpheus|playai|computer|codex|safeguard|-pro")
        data = sorted(j.get("data", []), key=lambda m: -(m.get("created") or 0))
        ms = [(m["id"], m["id"]) for m in data
              if (pid == "groq" or re.match(r"(gpt|o\d|chatgpt)", m["id"]))
              and not re.search(bad, m["id"]) and m.get("active", True)]
    if not ms:
        raise ApiError("Anahtar çalışıyor ama kullanılabilir sohbet modeli bulunamadı.")
    return [{"id": i, "label": l} for i, l in ms]


# ───────────────────────── İstek kurucular ─────────────────────────
IMG_OK = {"image/png", "image/jpeg", "image/webp", "image/gif"}


def expand(msgs, pid):
    """Tarayıcıdan gelen mesajları sağlayıcıdan bağımsız parçalara çevirir."""
    out = []
    for m in msgs:
        role = "assistant" if m.get("role") == "assistant" else "user"
        parts = []
        for a in m.get("att") or []:
            k, n = a.get("kind"), a.get("name", "dosya")
            if k == "text":
                parts.append(("text", f"[Ek dosya: {n}]\n```\n{a.get('text', '')}\n```"))
            elif k == "image" and a.get("data"):
                mime = a.get("mime") if a.get("mime") in IMG_OK else "image/jpeg"
                parts.append(("image", mime, a["data"]))
            elif k == "video" and pid == "gemini" and a.get("data"):
                parts.append(("video", a.get("mime") or "video/mp4", a["data"]))
            elif k in ("video", "frames") and a.get("frames"):
                parts.append(("text", f"[Video: {n} — {len(a['frames'])} kare, zaman sırasıyla]"))
                parts += [("image", "image/jpeg", f) for f in a["frames"]]
            elif k == "pdf" and a.get("data"):
                if pid not in ("anthropic", "gemini"):
                    raise ApiError("PDF dosyalarını yalnızca Claude ve Gemini okuyabilir. Sağlayıcıyı değiştir.")
                parts.append(("pdf", a["data"]))
            else:
                parts.append(("text", f"[Önceki ek: {n} — içerik saklanmadı]"))
        if m.get("content"):
            parts.append(("text", m["content"]))
        if parts:
            out.append((role, parts))
    return out


def build_request(pid, key, model, turns, system, temp, with_temp):
    if pid == "anthropic":
        msgs = []
        for role, parts in turns:
            c = []
            for p in parts:
                if p[0] == "text":
                    c.append({"type": "text", "text": p[1]})
                elif p[0] == "image":
                    c.append({"type": "image", "source": {"type": "base64", "media_type": p[1], "data": p[2]}})
                elif p[0] == "pdf":
                    c.append({"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": p[1]}})
            msgs.append({"role": role, "content": c})
        body = {"model": model, "max_tokens": 8192, "stream": True, "messages": msgs}
        if system:
            body["system"] = system
        if with_temp:
            body["temperature"] = min(temp, 1.0)
        return "/v1/messages", auth_headers(pid, key), body

    if pid == "gemini":
        contents = []
        for role, parts in turns:
            ps = []
            for p in parts:
                if p[0] == "text":
                    ps.append({"text": p[1]})
                elif p[0] in ("image", "video"):
                    ps.append({"inline_data": {"mime_type": p[1], "data": p[2]}})
                elif p[0] == "pdf":
                    ps.append({"inline_data": {"mime_type": "application/pdf", "data": p[1]}})
            contents.append({"role": "model" if role == "assistant" else "user", "parts": ps})
        body = {"contents": contents}
        if system:
            body["systemInstruction"] = {"parts": [{"text": system}]}
        if with_temp:
            body["generationConfig"] = {"temperature": temp}
        return f"/v1beta/models/{model}:streamGenerateContent?alt=sse", auth_headers(pid, key), body

    msgs = [{"role": "system", "content": system}] if system else []       # openai & groq
    for role, parts in turns:
        if all(p[0] == "text" for p in parts):
            content = "\n\n".join(p[1] for p in parts)
        else:
            content = [{"type": "text", "text": p[1]} if p[0] == "text"
                       else {"type": "image_url", "image_url": {"url": f"data:{p[1]};base64,{p[2]}"}}
                       for p in parts if p[0] in ("text", "image")]
        msgs.append({"role": role, "content": content})
    body = {"model": model, "stream": True, "messages": msgs}
    if with_temp and not (pid == "openai" and re.match(r"(o\d|gpt-5)", model)):
        body["temperature"] = temp
    path = "/v1/chat/completions" if pid == "openai" else "/openai/v1/chat/completions"
    return path, auth_headers(pid, key), body


def sse(resp):
    while True:
        try:
            line = resp.readline()
        except http.client.IncompleteRead:
            return
        if not line:
            return
        line = line.strip()
        if line.startswith(b"data:"):
            d = line[5:].strip()
            if d == b"[DONE]":
                return
            try:
                yield json.loads(d)
            except ValueError:
                continue


def deltas(pid, resp):
    for ev in sse(resp):
        if pid == "anthropic":
            t = ev.get("type")
            if t == "content_block_delta":
                d = ev.get("delta", {})
                if d.get("type") == "text_delta" and d.get("text"):
                    yield d["text"]
            elif t == "error":
                raise ApiError(ev.get("error", {}).get("message", "Akış hatası"))
            elif t == "message_stop":
                return
        elif pid == "gemini":
            if ev.get("error"):
                raise ApiError(err_text(json.dumps(ev)))
            br = ev.get("promptFeedback", {}).get("blockReason")
            if br:
                raise ApiError(f"Gemini içeriği engelledi ({br}).")
            for c in ev.get("candidates", []):
                for p in c.get("content", {}).get("parts", []):
                    if p.get("text") and not p.get("thought"):
                        yield p["text"]
        else:
            if ev.get("error"):
                raise ApiError(err_text(json.dumps(ev)))
            for c in ev.get("choices", []):
                t = (c.get("delta") or {}).get("content")
                if t:
                    yield t


def open_stream(pid, key, model, turns, system, temp):
    if not re.fullmatch(r"[A-Za-z0-9._:/\-]+", model or ""):
        raise ApiError("Geçersiz model adı.")
    for with_temp in (True, False):
        path, hdr, body = build_request(pid, key, model, turns, system, temp, with_temp)
        resp, conn = call(PROV[pid]["host"], "POST", path, hdr, body)
        if resp.status < 400:
            return resp, conn
        raw = resp.read()
        conn.close()
        # Bazı (özellikle yeni/akıl yürüten) modeller temperature kabul etmez → onsuz tekrar dene
        if resp.status == 400 and with_temp and re.search(r"temperature", raw.decode("utf-8", "replace"), re.I):
            continue
        raise http_error(resp.status, raw, pid)


def watch_client(sock, holder, stop):
    """Tarayıcı 'Durdur'a basıp bağlantıyı keserse sağlayıcıya giden isteği de hemen kes (token yakma)."""
    while not stop.wait(0.35):
        try:
            r, _, _ = select.select([sock], [], [], 0)
            if r and sock.recv(1, socket.MSG_PEEK) == b"":
                holder["abort"] = True
                c = holder.get("c")
                if c is not None:
                    try:
                        c.sock.shutdown(socket.SHUT_RDWR)
                    except Exception:
                        pass
                    c.close()
                return
        except Exception:
            return


# ───────────────────────── API uçları ─────────────────────────
def api_key(b):
    pid = b.get("provider")
    if pid not in PROV:
        return {"ok": False, "error": "Bilinmeyen sağlayıcı."}
    if b.get("remove"):
        def rm(c):
            c["keys"].pop(pid, None)
            c["models"].pop(pid, None)
        update_cfg(rm)
        return {"ok": True, "state": state()}
    raw = b.get("key") or ""
    if raw.strip():
        key = clean_key(raw)
        if not key.isascii() or len(key) < 12:
            return {"ok": False, "state": state(),
                    "error": "Anahtar geçersiz görünüyor (çok kısa ya da Türkçe/özel karakter içeriyor). "
                             "Sağlayıcının sitesinden kopyalayıp yeniden yapıştır."}
        g = guess_provider(key)
        if g and g != pid:
            return {"ok": False, "state": state(),
                    "error": f"Bu anahtar {PROV[g]['name']} anahtarına benziyor — {PROV[g]['name']} satırına yapıştır."}
        update_cfg(lambda c: c["keys"].__setitem__(pid, key))
    else:
        key = get_key(pid)
        if not key:
            return {"ok": False, "state": state(), "error": "Önce bir anahtar yapıştır."}
    try:
        models = fetch_models(pid, key)
    except ApiError as e:
        return {"ok": False, "error": str(e), "state": state()}
    update_cfg(lambda c: c["models"].__setitem__(pid, models))
    return {"ok": True, "count": len(models), "state": state()}


def api_config(b):
    def f(c):
        if b.get("provider") in PROV:
            c["provider"] = b["provider"]
        if isinstance(b.get("model"), dict):
            c["model"].update({k: v for k, v in b["model"].items() if k in PROV and isinstance(v, str)})
        if isinstance(b.get("system"), str):
            c["system"] = b["system"][:8000]
        if isinstance(b.get("temp"), (int, float)):
            c["temp"] = max(0.0, min(2.0, float(b["temp"])))
        if b.get("theme") in ("dark", "light"):
            c["theme"] = b["theme"]
    update_cfg(f)
    return {"ok": True}


class Handler(BaseHTTPRequestHandler):
    server_version = "NexusCore"

    def setup(self):
        super().setup()
        try:
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass

    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b)

    def _guard(self):
        host = (self.headers.get("Host") or "").rsplit(":", 1)[0]
        if host not in ("127.0.0.1", "localhost"):
            self._json({"error": "yasak"}, 403)
            return False
        return True

    def _authed(self):
        q = parse_qs(urlparse(self.path).query)
        t = self.headers.get("X-Nexus-Token") or (q.get("t") or [""])[0]
        if not secrets.compare_digest(t.encode("utf-8", "replace"), TOKEN.encode()):
            self._json({"error": "Oturum doğrulanamadı — uygulamayı yeniden aç."}, 401)
            return False
        return True

    def do_GET(self):
        if not self._guard():
            return
        p = urlparse(self.path).path
        if p == "/":
            LIFE["bye"] = 0.0
            b = PAGE.replace("__TOKEN__", TOKEN).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(b)
        elif p.startswith("/api/"):
            if not self._authed():
                return
            if p == "/api/state":
                self._json(state())
            elif p == "/api/chats":
                try:
                    self._json(json.loads(CHAT_FILE.read_text("utf-8")))
                except Exception:
                    self._json([])
            else:
                self._json({"error": "yok"}, 404)
        elif p == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
        else:
            self._json({"error": "yok"}, 404)

    def do_POST(self):
        if not self._guard():
            return
        p = urlparse(self.path).path
        if not self._authed():
            return
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            self._json({"error": "İstek çok büyük."}, 413)
            return
        raw = self.rfile.read(n) if n else b"{}"
        try:
            b = json.loads(raw or b"{}")
        except ValueError:
            self._json({"error": "Geçersiz JSON."}, 400)
            return
        try:
            if p == "/api/chat":
                self.chat(b)
            elif p == "/api/key":
                self._json(api_key(b))
            elif p == "/api/config":
                self._json(api_config(b))
            elif p == "/api/chats":
                with LOCK:
                    save_json(CHAT_FILE, b if isinstance(b, list) else [])
                self._json({"ok": True})
            elif p == "/api/ping":
                LIFE.update(seen=True, last=time.time(), bye=0.0)
                self._json({"ok": True})
            elif p == "/api/bye":
                LIFE["bye"] = time.time()
                self._json({"ok": True})
            else:
                self._json({"error": "yok"}, 404)
        except ApiError as e:
            self._json({"error": str(e)}, 400)
        except Exception as e:
            log(traceback.format_exc())
            self._json({"error": f"Beklenmeyen hata: {e}"}, 500)

    do_PUT = do_POST

    # ── Akışlı sohbet: NDJSON satırları  {"t":"metin"} | {"err":"..."} | {"done":true}
    def chat(self, b):
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        self.close_connection = True
        holder, stop = {}, threading.Event()
        threading.Thread(target=watch_client, args=(self.connection, holder, stop), daemon=True).start()

        def emit(o):
            self.wfile.write((json.dumps(o, ensure_ascii=False) + "\n").encode("utf-8"))

        conn = resp = None
        ok = False
        pid = b.get("provider")
        try:
            if pid not in PROV:
                raise ApiError("Bilinmeyen sağlayıcı.")
            key = get_key(pid)
            if not key:
                raise ApiError(f"{PROV[pid]['name']} için API anahtarı yok. Ayarlar'dan ekle.", "auth")
            temp = max(0.0, min(2.0, float(b.get("temp", 0.7))))
            turns = expand(b.get("messages") or [], pid)
            if not turns:
                raise ApiError("Gönderilecek mesaj yok.")
            resp, conn = open_stream(pid, key, b.get("model", ""), turns, (b.get("system") or "").strip(), temp)
            holder["c"] = conn
            if holder.get("abort"):
                return
            for t in deltas(pid, resp):
                emit({"t": t})
            ok = True
            emit({"done": True})
        except ApiError as e:
            if not holder.get("abort"):
                try:
                    emit({"err": str(e), "code": e.code})
                except Exception:
                    pass
        except (BrokenPipeError, ConnectionError):
            pass
        except Exception as e:
            if not holder.get("abort"):
                log(traceback.format_exc())
                try:
                    emit({"err": f"Beklenmeyen hata: {e.__class__.__name__}: {e}"})
                except Exception:
                    pass
        finally:
            stop.set()
            if conn is not None:
                if ok:
                    _give(PROV[pid]["host"], conn, resp)
                else:
                    try:
                        conn.close()
                    except Exception:
                        pass


# ───────────────────────── Açılış & kapanış ─────────────────────────
def open_window(url):
    if sys.platform == "win32":
        bases = [os.environ.get(k) for k in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")]
        for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
            for base in filter(None, bases):
                exe = Path(base) / rel
                if exe.exists():
                    try:
                        subprocess.Popen([str(exe), f"--app={url}", "--window-size=1320,880",
                                          f"--user-data-dir={DATA / 'window'}", "--no-first-run",
                                          "--no-default-browser-check"])
                        return
                    except Exception:
                        pass
    webbrowser.open(url)


def watchdog(srv):
    while True:
        time.sleep(1)
        now = time.time()
        if LIFE["bye"] and now - LIFE["bye"] > 5:
            break
        if LIFE["seen"] and now - LIFE["last"] > 150:
            break
    srv.shutdown()


def main():
    srv = None
    for port in (8765, 0):
        try:
            srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
            break
        except OSError:
            continue
    if srv is None:
        sys.exit("Yerel sunucu başlatılamadı.")
    srv.daemon_threads = True
    url = f"http://127.0.0.1:{srv.server_port}/"
    log("başladı", url)
    if sys.stdout:
        print(f"NEXUS CORE v{VERSION}  →  {url}\nPencere kapanınca program da kapanır. (Ctrl+C ile çık)")
    if "--keep" not in sys.argv:
        threading.Thread(target=watchdog, args=(srv,), daemon=True).start()
    if "--no-window" not in sys.argv:
        open_window(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


# ───────────────────────── Arayüz ─────────────────────────
PAGE = r"""<!doctype html>
<html lang="tr" data-provider="anthropic" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>NEXUS CORE</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cpath d='M16 3l11 6.3v12.6L16 28.2 5 21.9V9.3z' fill='%237c5cff'/%3E%3Ccircle cx='16' cy='16' r='3.2' fill='%23fff'/%3E%3C/svg%3E">
<style>
@property --a1{syntax:'<color>';inherits:true;initial-value:#d97757}
@property --a2{syntax:'<color>';inherits:true;initial-value:#f2a07b}
:root{--bg:#090b10;--panel:rgba(255,255,255,.05);--panel2:rgba(255,255,255,.09);--line:rgba(255,255,255,.1);--tx:#eef0f6;--mut:#8b90a3;--ok:#3ddc97;--bad:#ff6b6b;--glass:rgba(14,16,24,.66);--code:#0c0f16;transition:--a1 .7s,--a2 .7s;color-scheme:dark}
[data-theme=light]{--bg:#f2f3f8;--panel:rgba(255,255,255,.65);--panel2:rgba(255,255,255,.95);--line:rgba(20,24,40,.12);--tx:#161a28;--mut:#656b82;--glass:rgba(255,255,255,.72);color-scheme:light}
[data-provider=anthropic]{--a1:#d97757;--a2:#f2a07b}
[data-provider=openai]{--a1:#10a37f;--a2:#5ee0bd}
[data-provider=gemini]{--a1:#4f8cff;--a2:#b172ff}
[data-provider=groq]{--a1:#f55036;--a2:#ffa04d}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{background:var(--bg);color:var(--tx);font:15px/1.6 "Segoe UI Variable Text","Segoe UI",Inter,system-ui,sans-serif;overflow:hidden;-webkit-font-smoothing:antialiased}
button{font:inherit;color:inherit;cursor:pointer}
svg{flex:none}
::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-thumb{background:var(--line);border-radius:10px;border:3px solid transparent;background-clip:content-box}
.aurora{position:fixed;inset:0;overflow:hidden;z-index:0;pointer-events:none}
.aurora i{position:absolute;width:55vmax;height:55vmax;border-radius:50%;filter:blur(100px);opacity:.26;animation:drift 24s ease-in-out infinite alternate}
.aurora i:nth-child(1){background:var(--a1);left:-18vmax;top:-24vmax}
.aurora i:nth-child(2){background:var(--a2);right:-22vmax;bottom:-28vmax;animation-duration:30s;animation-delay:-9s}
.aurora i:nth-child(3){background:#5b6cff;left:38%;top:42%;width:28vmax;height:28vmax;opacity:.12;animation-duration:36s}
[data-theme=light] .aurora i{opacity:.16}
@keyframes drift{to{transform:translate(9vmax,6vmax) scale(1.18)}}
.app{position:relative;z-index:1;display:grid;grid-template-columns:272px 1fr;height:100%}
.ghost{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:8px 12px;display:inline-flex;align-items:center;gap:8px;transition:.2s}
.ghost:hover{background:var(--panel2);transform:translateY(-1px)}
.ghost:active{transform:none}
/* sidebar */
.side{background:var(--glass);backdrop-filter:blur(26px);border-right:1px solid var(--line);display:flex;flex-direction:column;padding:16px;gap:14px;min-height:0}
.brand{display:flex;align-items:center;gap:11px}
.brand b{letter-spacing:.2em;font-size:14px;display:block;line-height:1.1}
.brand small{color:var(--mut);letter-spacing:.14em;font-size:10px}
.brand svg{filter:drop-shadow(0 0 10px var(--a1));animation:pulse 3.4s ease-in-out infinite}
@keyframes pulse{50%{filter:drop-shadow(0 0 18px var(--a2));transform:scale(1.06)}}
.newbtn{border:1px solid color-mix(in srgb,var(--a1) 50%,transparent);background:linear-gradient(135deg,color-mix(in srgb,var(--a1) 22%,transparent),color-mix(in srgb,var(--a2) 10%,transparent));border-radius:14px;padding:11px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:8px;transition:.25s}
.newbtn:hover{box-shadow:0 8px 30px -8px var(--a1);transform:translateY(-2px)}
.list{flex:1;overflow:auto;display:flex;flex-direction:column;gap:3px;margin:0 -6px;padding:0 6px}
.item{display:flex;align-items:center;gap:8px;padding:9px 11px;border-radius:12px;cursor:pointer;color:var(--mut);transition:.2s}
.item span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px}
.item:hover{background:var(--panel);color:var(--tx)}
.item.on{background:var(--panel2);color:var(--tx);box-shadow:inset 3px 0 0 var(--a1)}
.item .x{opacity:0;background:none;border:0;color:var(--mut);padding:2px;border-radius:6px;display:grid}
.item:hover .x{opacity:1}.item .x:hover{color:var(--bad)}
.empty{color:var(--mut);font-size:13px;text-align:center;padding:20px 8px}
.foot{display:flex;gap:8px}.foot .ghost:first-child{flex:1}
/* main */
.main{display:flex;flex-direction:column;min-width:0;min-height:0;height:100%}
.top{display:flex;align-items:center;gap:12px;padding:14px 22px;flex-wrap:wrap}
.menu{display:none}
.seg{position:relative;display:flex;padding:4px;border-radius:16px;background:var(--panel);border:1px solid var(--line);backdrop-filter:blur(14px)}
.seg button{position:relative;z-index:1;display:flex;gap:8px;align-items:center;padding:7px 13px;border:0;background:none;color:var(--mut);border-radius:12px;font-weight:600;transition:color .25s}
.seg button:hover,.seg button.on{color:var(--tx)}
.seg .ind{position:absolute;z-index:0;top:4px;bottom:4px;border-radius:12px;background:linear-gradient(135deg,color-mix(in srgb,var(--a1) 30%,transparent),color-mix(in srgb,var(--a2) 16%,transparent));border:1px solid color-mix(in srgb,var(--a1) 55%,transparent);transition:left .4s cubic-bezier(.3,1.35,.5,1),width .35s}
.dot{width:6px;height:6px;border-radius:50%;background:var(--ok);box-shadow:0 0 8px var(--ok)}
.nokey .dot{background:var(--mut);box-shadow:none;opacity:.5}
.sp{flex:1}
select{background:var(--panel);color:var(--tx);border:1px solid var(--line);border-radius:12px;padding:9px 12px;font:inherit;max-width:260px;outline:none;transition:.2s}
select:hover,select:focus{border-color:color-mix(in srgb,var(--a1) 60%,transparent)}
select option{background:var(--bg);color:var(--tx)}
.msgs{flex:1;overflow:auto;padding:6px 22px 20px;min-height:0}
.wrap{max-width:820px;margin:0 auto}
.m{display:flex;gap:13px;margin:20px 0}
.m.new{animation:rise .5s cubic-bezier(.2,.8,.2,1) both}
@keyframes rise{from{opacity:0;transform:translateY(14px);filter:blur(4px)}to{opacity:1;transform:none;filter:none}}
.m.u{justify-content:flex-end}
.col{min-width:0;display:flex;flex-direction:column;gap:6px;max-width:100%}
.m.u .col{align-items:flex-end;max-width:82%}
.m.u .b{background:color-mix(in srgb,var(--a1) 20%,var(--panel2));border:1px solid color-mix(in srgb,var(--a1) 35%,transparent);padding:10px 16px;border-radius:20px 20px 6px 20px;white-space:pre-wrap;word-break:break-word}
.av{width:34px;height:34px;border-radius:12px;background:var(--panel2);border:1px solid var(--line);display:grid;place-items:center;margin-top:2px;flex:none}
.m.a .col{flex:1}
.meta{display:flex;gap:12px;align-items:center;font-size:12px;color:var(--mut);min-height:22px}
.acts{display:flex;gap:4px;opacity:0;transition:.2s}.m:hover .acts{opacity:1}
.acts button{background:none;border:0;color:var(--mut);padding:3px 6px;border-radius:8px;display:flex;gap:5px;align-items:center;font-size:12px}
.acts button:hover{background:var(--panel2);color:var(--tx)}
.err{border:1px solid color-mix(in srgb,var(--bad) 50%,transparent);background:color-mix(in srgb,var(--bad) 10%,transparent);border-radius:14px;padding:12px 14px;white-space:pre-wrap;font-size:14px}
.lnk{margin-top:8px;display:block;background:var(--bad);color:#fff;border:0;border-radius:10px;padding:6px 12px;font-weight:600}
.think{display:flex;gap:5px;padding:12px 2px}.think i{width:8px;height:8px;border-radius:50%;background:linear-gradient(135deg,var(--a1),var(--a2));animation:bounce 1.1s infinite ease-in-out}
.think i:nth-child(2){animation-delay:.15s}.think i:nth-child(3){animation-delay:.3s}
@keyframes bounce{0%,80%,100%{transform:scale(.5);opacity:.4}40%{transform:scale(1.15);opacity:1}}
.md>*:first-child{margin-top:0}.md p{margin:.55em 0}.md h2,.md h3,.md h4,.md h5{margin:1.1em 0 .4em;line-height:1.3}
.md ul,.md ol{margin:.5em 0 .5em 1.4em}.md li{margin:.2em 0}
.md a{color:var(--a2)}.md hr{border:0;border-top:1px solid var(--line);margin:1em 0}
.md blockquote{border-left:3px solid var(--a1);padding:2px 0 2px 14px;color:var(--mut);margin:.7em 0}
.md code{background:color-mix(in srgb,var(--a1) 14%,transparent);padding:1px 6px;border-radius:6px;font:13px Consolas,"Cascadia Code",monospace}
.code{margin:.8em 0;border-radius:14px;overflow:hidden;border:1px solid var(--line);background:var(--code);color:#dfe3ee}
.ch{display:flex;justify-content:space-between;align-items:center;padding:6px 8px 6px 14px;background:rgba(255,255,255,.05);font-size:12px;color:#9aa0b4}
.ch button{background:none;border:0;color:#9aa0b4;padding:3px 8px;border-radius:7px}.ch button:hover{background:rgba(255,255,255,.1);color:#fff}
.code pre{padding:12px 14px;overflow:auto}.code code{background:none;padding:0;font:13px/1.55 Consolas,"Cascadia Code",monospace;color:inherit}
.tw{overflow:auto;margin:.8em 0}table{border-collapse:collapse;min-width:60%}th,td{border:1px solid var(--line);padding:7px 12px;text-align:left}th{background:var(--panel2)}
.md.live>:last-child::after{content:"";display:inline-block;width:8px;height:1.05em;margin-left:3px;vertical-align:-.15em;background:var(--a1);border-radius:2px;animation:blink 1s steps(2) infinite}
@keyframes blink{50%{opacity:0}}
.atts{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
.th{width:84px;height:84px;object-fit:cover;border-radius:12px;border:1px solid var(--line)}
.th.vid{position:relative}.th.vid img{width:100%;height:100%;object-fit:cover;border-radius:12px}
.th.vid i{position:absolute;inset:0;display:grid;place-items:center;font-style:normal;color:#fff;background:rgba(0,0,0,.35);border-radius:12px}
.chip{display:inline-flex;gap:6px;align-items:center;padding:5px 10px;border-radius:10px;background:var(--panel2);border:1px solid var(--line);font-size:13px;max-width:240px}
.chip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* hero */
.hero{max-width:760px;margin:6vh auto 0;text-align:center;animation:rise .7s both}
.orb{position:relative;width:108px;height:108px;margin:0 auto 22px;display:grid;place-items:center}
.orb .ring{position:absolute;inset:0;border-radius:50%;background:conic-gradient(from 0deg,var(--a1),var(--a2),transparent 62%,var(--a1));animation:spin 6s linear infinite;-webkit-mask:radial-gradient(circle,transparent 63%,#000 65%);mask:radial-gradient(circle,transparent 63%,#000 65%)}
.orb .core{width:86px;height:86px;border-radius:50%;background:var(--panel2);display:grid;place-items:center;box-shadow:0 0 70px -10px var(--a1);animation:float 4.5s ease-in-out infinite}
@keyframes spin{to{transform:rotate(360deg)}}@keyframes float{50%{transform:translateY(-6px)}}
.hero h1{font-size:34px;letter-spacing:-.02em;background:linear-gradient(90deg,var(--tx),var(--a2),var(--a1),var(--tx));background-size:250% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:shine 7s linear infinite}
@keyframes shine{to{background-position:250% 0}}
.hero p{color:var(--mut);margin:8px 0 26px}
.cards{display:grid;grid-template-columns:1fr 1fr;gap:12px;text-align:left}
.card{position:relative;overflow:hidden;background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:16px;display:flex;flex-direction:column;gap:3px;transition:.25s;--mx:50%;--my:50%}
.card::before{content:"";position:absolute;inset:0;background:radial-gradient(260px circle at var(--mx) var(--my),color-mix(in srgb,var(--a1) 24%,transparent),transparent 70%);opacity:0;transition:opacity .3s}
.card:hover{transform:translateY(-3px);border-color:color-mix(in srgb,var(--a1) 55%,transparent)}.card:hover::before{opacity:1}
.card>*{position:relative}.card span{font-size:22px}.card small{color:var(--mut);font-size:13px}
.cta{margin-top:18px;background:linear-gradient(135deg,var(--a1),var(--a2));color:#fff;border:0;border-radius:14px;padding:11px 22px;font-weight:700;box-shadow:0 10px 30px -10px var(--a1)}
/* composer */
.comp{padding:0 22px 14px}
.box{max-width:820px;margin:0 auto;background:var(--glass);backdrop-filter:blur(22px);border:1px solid var(--line);border-radius:24px;padding:10px 10px 8px 14px;transition:border-color .25s,box-shadow .25s}
.box:focus-within{border-color:color-mix(in srgb,var(--a1) 65%,transparent);box-shadow:0 0 0 4px color-mix(in srgb,var(--a1) 14%,transparent),0 12px 44px -14px var(--a1)}
textarea{width:100%;background:none;border:0;outline:0;resize:none;color:var(--tx);font:inherit;max-height:200px;padding:6px 0}
textarea::placeholder{color:var(--mut)}
.row{display:flex;align-items:center;gap:8px}.row .sp{flex:1}
.row .ghost{padding:8px;border-radius:12px}
.send{width:40px;height:40px;border-radius:50%;border:0;background:linear-gradient(135deg,var(--a1),var(--a2));color:#fff;display:grid;place-items:center;transition:.25s;box-shadow:0 8px 24px -8px var(--a1)}
.send:hover{transform:scale(1.1) rotate(-6deg)}.send:active{transform:scale(.94)}
.send.stop{animation:ring 1.4s infinite}
@keyframes ring{0%{box-shadow:0 0 0 0 color-mix(in srgb,var(--a1) 60%,transparent)}100%{box-shadow:0 0 0 14px transparent}}
.chips{display:flex;gap:8px;flex-wrap:wrap;padding-bottom:6px}.chips:empty{display:none}
.pc{position:relative;display:flex;align-items:center;gap:8px;background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:4px 8px 4px 4px;font-size:13px;max-width:220px;animation:rise .3s both}
.pc img{width:38px;height:38px;object-fit:cover;border-radius:9px}.pc .ic{width:38px;height:38px;display:grid;place-items:center;font-size:18px}
.pc span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pc small{display:block;color:var(--mut);font-size:11px}
.pc button{background:none;border:0;color:var(--mut);padding:2px 4px}.pc button:hover{color:var(--bad)}
.spin{width:16px;height:16px;border-radius:50%;border:2px solid var(--line);border-top-color:var(--a1);animation:spin .8s linear infinite}
.fine{text-align:center;color:var(--mut);font-size:11.5px;margin-top:8px}
/* modal */
.modal{position:fixed;inset:0;z-index:50;display:none;place-items:center;background:rgba(5,6,10,.55);backdrop-filter:blur(10px)}
.modal.on{display:grid;animation:fade .25s}
@keyframes fade{from{opacity:0}}
.sheet{width:min(740px,94vw);max-height:90vh;overflow:auto;background:var(--bg);border:1px solid var(--line);border-radius:26px;padding:24px;box-shadow:0 40px 120px -30px #000;animation:pop .4s cubic-bezier(.2,1.2,.3,1)}
@keyframes pop{from{opacity:0;transform:scale(.92) translateY(16px)}}
.sheet h2{display:flex;justify-content:space-between;align-items:center;font-size:20px;margin-bottom:4px}
.sheet .sub{color:var(--mut);font-size:13px;margin-bottom:16px}
.krow{border:1px solid var(--line);background:var(--panel);border-radius:18px;padding:14px;margin-bottom:12px;transition:.3s}
.krow.focus{border-color:var(--a1);box-shadow:0 0 0 4px color-mix(in srgb,var(--a1) 15%,transparent)}
.kh{display:flex;align-items:center;gap:10px;margin-bottom:10px}.kh a{margin-left:auto;color:var(--a2);font-size:13px;text-decoration:none}
.stat{font-size:12px;padding:2px 9px;border-radius:20px;background:var(--panel2);color:var(--mut)}.stat.ok{color:var(--ok)}.stat.warn{color:#ffb454}
.kin{display:flex;gap:8px}.kin input{flex:1;min-width:0;background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:9px 12px;color:var(--tx);font:13px Consolas,monospace;outline:0}
.kin input:focus{border-color:var(--a1)}
.pri{background:linear-gradient(135deg,var(--a1),var(--a2));color:#fff;border:0;border-radius:12px;padding:8px 14px;font-weight:600;white-space:nowrap;transition:.2s}.pri:hover{filter:brightness(1.1)}.pri:disabled{opacity:.6}
.kmsg{font-size:13px;margin-top:8px;white-space:pre-wrap}.kmsg.bad{color:var(--bad)}.kmsg.good{color:var(--ok)}
.sheet label{display:block;font-weight:600;margin:14px 0 6px;font-size:14px}
.sheet textarea{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:10px 12px;min-height:84px}
.sheet input[type=range]{width:100%;accent-color:var(--a1)}
#toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:90;display:flex;flex-direction:column;gap:8px;align-items:center;pointer-events:none}
.toast{background:var(--panel2);backdrop-filter:blur(20px);border:1px solid var(--line);padding:10px 18px;border-radius:14px;box-shadow:0 14px 40px -12px #000;animation:rise .35s both;max-width:80vw;font-size:14px}
.drop{position:fixed;inset:14px;z-index:80;border:2px dashed var(--a1);border-radius:28px;background:color-mix(in srgb,var(--a1) 12%,transparent);backdrop-filter:blur(6px);display:none;place-items:center;font-size:22px;font-weight:700;pointer-events:none}
.drop.on{display:grid;animation:fade .2s}
@media(max-width:860px){.app{grid-template-columns:1fr}.side{position:fixed;left:0;top:0;bottom:0;width:272px;transform:translateX(-102%);transition:transform .3s;z-index:30}.side.open{transform:none}.menu{display:inline-flex}.cards{grid-template-columns:1fr}.seg button span{display:none}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style>
</head>
<body>
<svg width="0" height="0" style="position:absolute"><defs>
<linearGradient id="gg" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#4f8cff"/><stop offset=".55" stop-color="#9b72cb"/><stop offset="1" stop-color="#ee7a90"/></linearGradient>
<linearGradient id="bg1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" style="stop-color:var(--a1)"/><stop offset="1" style="stop-color:var(--a2)"/></linearGradient>
</defs></svg>
<div class="aurora"><i></i><i></i><i></i></div>
<div class="app">
<aside class="side" id="side">
  <div class="brand"><span id="brandLogo"></span><div><b>NEXUS</b><small>CORE · v2</small></div></div>
  <button class="newbtn" id="newChat"></button>
  <div class="list" id="list"></div>
  <div class="foot"><button class="ghost" id="openSet"></button><button class="ghost" id="themeBtn" title="Tema"></button></div>
</aside>
<main class="main">
  <header class="top">
    <button class="ghost menu" id="menu"></button>
    <div class="seg" id="seg"></div>
    <span class="sp"></span>
    <select id="model" title="Model"></select>
    <button class="ghost" id="refresh" title="Model listesini yenile"></button>
  </header>
  <section class="msgs" id="msgs"></section>
  <footer class="comp">
    <div class="box">
      <div class="chips" id="chips"></div>
      <textarea id="ta" rows="1" placeholder="Bir şey yaz…  (Enter: gönder · Shift+Enter: yeni satır)"></textarea>
      <div class="row"><button class="ghost" id="attach" title="Fotoğraf, video, PDF veya kod dosyası ekle"></button><span class="sp"></span><button class="send" id="send" title="Gönder"></button></div>
    </div>
    <input type="file" id="file" multiple hidden accept="image/*,video/*,.pdf,.txt,.md,.py,.js,.ts,.jsx,.tsx,.json,.csv,.tsv,.html,.htm,.css,.xml,.yaml,.yml,.log,.sql,.java,.c,.h,.cpp,.cs,.go,.rs,.php,.rb,.sh,.bat,.ps1,.ini,.toml,.cfg">
    <p class="fine">Yapay zekâ hata yapabilir — önemli bilgileri doğrula.  ·  Ctrl+K: yeni sohbet</p>
  </footer>
</main>
</div>
<div class="modal" id="modal"><div class="sheet">
  <h2><span>Ayarlar</span><button class="ghost" id="closeSet"></button></h2>
  <p class="sub">API anahtarların yalnızca bu bilgisayardaki yerel dosyada saklanır ve doğrudan ilgili şirkete gönderilir.</p>
  <div id="keys"></div>
  <label for="sys">Sistem talimatı (tüm sohbetlerde geçerli)</label>
  <textarea id="sys" placeholder="Örn: Her zaman Türkçe, kısa ve net cevap ver."></textarea>
  <label for="temp">Yaratıcılık (temperature): <b id="tv"></b></label>
  <input type="range" id="temp" min="0" max="1.5" step="0.05">
</div></div>
<div class="drop" id="drop">Dosyayı buraya bırak</div>
<div id="toast"></div>
<script>
const TOKEN="__TOKEN__";
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const api=(path,body,method)=>fetch(path,{method:method||(body===undefined?'GET':'POST'),headers:{'X-Nexus-Token':TOKEN,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)}).then(async r=>{const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j});
const S={st:null,chats:[],cur:null,att:[],busy:false,ctrl:null,saveT:0};

/* ───── ikonlar & logolar ───── */
const IC={
 plus:'<path d="M12 5v14M5 12h14"/>',clip:'<path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
 set:'<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
 trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',copy:'<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
 ref:'<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',menu:'<path d="M4 7h16M4 12h16M4 17h16"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',
 moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
 eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
 up:'<path d="M12 19V5M5 12l7-7 7 7"/>',chat:'<path d="M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.5A8 8 0 1 1 21 12z"/>'
};
const ic=(n,s=18)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${IC[n]}</svg>`;
const STOP='<svg width="18" height="18" viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="3" fill="currentColor"/></svg>';
const LOGO={ /* sadeleştirilmiş marka işaretleri */
 anthropic:s=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="#d97757" stroke-width="2.3" stroke-linecap="round">${[...Array(12)].map((_,i)=>{const a=i*Math.PI/6,l=i%2?7.4:10.4;return`<line x1="${(12+Math.cos(a)*2.4).toFixed(2)}" y1="${(12+Math.sin(a)*2.4).toFixed(2)}" x2="${(12+Math.cos(a)*l).toFixed(2)}" y2="${(12+Math.sin(a)*l).toFixed(2)}"/>`}).join('')}</svg>`,
 openai:s=>`<svg width="${s}" height="${s}" viewBox="-12 -12 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">${[0,1,2,3,4,5].map(i=>`<rect x="-3.3" y="-10.6" width="6.6" height="11.4" rx="3.3" transform="rotate(${i*60})"/>`).join('')}</svg>`,
 gemini:s=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path fill="url(#gg)" d="M12 1.5C12.9 8 16 11.1 22.5 12 16 12.9 12.9 16 12 22.5 11.1 16 8 12.9 1.5 12 8 11.1 11.1 8 12 1.5Z"/></svg>`,
 groq:s=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24"><rect x="1" y="1" width="22" height="22" rx="7" fill="#f55036"/><path d="M16.3 8A5.6 5.6 0 1 0 17.6 12.2H12.4" fill="none" stroke="#fff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`
};
const logo=(p,s=22)=>(LOGO[p]||LOGO.anthropic)(s);
const BRAND=`<svg width="32" height="32" viewBox="0 0 32 32"><path d="M16 2.5l11.7 6.7v13.6L16 29.5 4.3 22.8V9.2z" fill="url(#bg1)"/><path d="M16 16V8.5M16 16l6.5 3.8M16 16l-6.5 3.8" stroke="#fff" stroke-width="1.7" stroke-linecap="round"/><circle cx="16" cy="16" r="3.3" fill="#fff"/></svg>`;

/* ───── güvenli mini markdown ───── */
function md(src){
  const code=[];
  src=src.replace(/```([\w+#.-]*)[^\n]*\n([\s\S]*?)(?:```|$)/g,(m,l,c)=>{code.push([l,c.replace(/\n$/,'')]);return '\n\u0001'+(code.length-1)+'\u0001\n'});
  const inl=s=>s.split(/(`[^`\n]+`)/).map((p,i)=>i%2?'<code>'+esc(p.slice(1,-1))+'</code>':esc(p)
    .replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/(^|[^*])\*([^*\n]+)\*/g,'$1<i>$2</i>').replace(/~~([^~\n]+)~~/g,'<s>$1</s>')
    .replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" target="_blank" rel="noopener">$1</a>')).join('');
  const L=src.split('\n');let h='',i=0,m;
  const blk=/^(\u0001\d+\u0001|#{1,4}\s|\s*>|\s*([-*+]|\d+[.)])\s+|\s*\|)/;
  while(i<L.length){
    const l=L[i];
    if(m=l.match(/^\u0001(\d+)\u0001$/)){const[lg,c]=code[+m[1]];h+=`<div class="code"><div class="ch"><span>${esc(lg||'kod')}</span><button class="cp">Kopyala</button></div><pre><code>${esc(c)}</code></pre></div>`;i++;continue}
    if(!l.trim()){i++;continue}
    if(m=l.match(/^(#{1,4})\s+(.*)/)){const n=m[1].length+1;h+=`<h${n}>${inl(m[2])}</h${n}>`;i++;continue}
    if(/^\s*([-*_])\1{2,}\s*$/.test(l)){h+='<hr>';i++;continue}
    if(/^\s*>/.test(l)){const b=[];while(i<L.length&&/^\s*>/.test(L[i])){b.push(L[i].replace(/^\s*>\s?/,''));i++}h+='<blockquote>'+inl(b.join(' '))+'</blockquote>';continue}
    if(/^\s*\|.*\|\s*$/.test(l)&&/^\s*\|?\s*:?-{2,}/.test(L[i+1]||'')){
      const row=s=>s.trim().replace(/^\||\|$/g,'').split('|').map(x=>x.trim());const hd=row(l),rows=[];i+=2;
      while(i<L.length&&/^\s*\|/.test(L[i])){rows.push(row(L[i]));i++}
      h+='<div class="tw"><table><thead><tr>'+hd.map(x=>`<th>${inl(x)}</th>`).join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(x=>`<td>${inl(x)}</td>`).join('')+'</tr>').join('')+'</tbody></table></div>';continue}
    if(/^\s*([-*+]|\d+[.)])\s+/.test(l)){const ord=/^\s*\d+[.)]/.test(l),it=[];let q;
      while(i<L.length&&(q=L[i].match(/^\s*(?:[-*+]|\d+[.)])\s+(.*)/))){it.push(inl(q[1]));i++}
      h+=`<${ord?'ol':'ul'}>`+it.map(x=>`<li>${x}</li>`).join('')+`</${ord?'ol':'ul'}>`;continue}
    const p=[];while(i<L.length&&L[i].trim()&&!blk.test(L[i])){p.push(L[i]);i++}
    if(!p.length){p.push(L[i]);i++}
    h+='<p>'+inl(p.join('\n')).replace(/\n/g,'<br>')+'</p>';
  }
  return h;
}

/* ───── yardımcılar ───── */
function toast(msg,ms=4200){const t=document.createElement('div');t.className='toast';t.textContent=msg;$('#toast').appendChild(t);setTimeout(()=>{t.style.transition='.3s';t.style.opacity=0;setTimeout(()=>t.remove(),300)},ms)}
const cur=()=>S.st.settings.provider, PV=()=>S.st.providers[cur()];
const newChat=()=>{const c={id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),title:'Yeni sohbet',ts:Date.now(),messages:[]};S.chats.unshift(c);S.cur=c;return c};
const slim=c=>({...c,messages:c.messages.map(m=>({...m,att:m.att&&m.att.map(a=>a.kind==='text'?a:{kind:'ref',k:a.kind,name:a.name})}))});
function save(now){clearTimeout(S.saveT);const go=()=>api('/api/chats',S.chats.filter(c=>c.messages.length).map(slim),'PUT').catch(()=>{});now?go():S.saveT=setTimeout(go,700)}
const saveCfg=o=>api('/api/config',o).catch(e=>toast(e.message));
const readB64=f=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result.split(',')[1]);r.onerror=()=>no(new Error('Dosya okunamadı'));r.readAsDataURL(f)});
const atBottom=()=>{const m=$('#msgs');return m.scrollHeight-m.scrollTop-m.clientHeight<140};
const scrollEnd=f=>{const m=$('#msgs');if(f||atBottom())m.scrollTop=m.scrollHeight};

/* ───── çizim ───── */
function renderAll(){renderSide();renderTop();renderMsgs();renderChips();setSendBtn()}
function renderSide(){
  const l=[...S.chats].filter(c=>c.messages.length||c===S.cur).sort((a,b)=>b.ts-a.ts);
  $('#list').innerHTML=l.length?l.map(c=>`<div class="item ${c===S.cur?'on':''}" data-id="${c.id}">${ic('chat',16)}<span>${esc(c.title)}</span><button class="x" data-del="${c.id}" title="Sil">${ic('x',15)}</button></div>`).join(''):'<div class="empty">Henüz sohbet yok</div>';
}
function renderTop(){
  const st=S.st,c=cur();
  $('#seg').innerHTML='<i class="ind"></i>'+Object.entries(st.providers).map(([id,p])=>`<button data-p="${id}" class="${id===c?'on':''} ${p.hasKey?'':'nokey'}" title="${p.hasKey?p.name:p.name+' — API anahtarı yok'}">${logo(id,19)}<span>${p.name}</span><b class="dot"></b></button>`).join('');
  moveInd();
  const P=st.providers[c];
  $('#model').innerHTML=P.models.map(m=>`<option value="${esc(m.id)}" ${m.id===P.model?'selected':''}>${esc(m.label)}</option>`).join('');
}
function moveInd(){const b=$('#seg .on'),i=$('#seg .ind');if(b&&i){i.style.left=b.offsetLeft+'px';i.style.width=b.offsetWidth+'px'}}
const SUG=[['🖼️','Görseli analiz et','Ekteki görselde ne olduğunu ayrıntılı anlat.'],['🎬','Videoyu özetle','Ekteki videoyu sahne sahne özetle.'],['💻','Kod yaz','Python ile bir klasördeki dosyaları tarihe göre sıralayan bir script yaz.'],['✨','Fikir üret','Hafta sonu yapabileceğim 5 yaratıcı proje fikri ver.']];
function heroHtml(){
  const p=cur(),P=PV();
  return `<div class="hero"><div class="orb"><span class="ring"></span><div class="core">${logo(p,46)}</div></div><h1>Bugün ne yapalım?</h1>
  <p>${P.name} ile konuşuyorsun · fotoğraf, video, PDF veya kod dosyası ekleyebilirsin.</p>
  ${P.hasKey?`<div class="cards">${SUG.map(([e,t,q])=>`<button class="card" data-q="${esc(q)}"><span>${e}</span><b>${t}</b><small>${esc(q)}</small></button>`).join('')}</div>`:`<button class="cta" data-act="settings">${P.name} API anahtarını ekle</button>`}</div>`;
}
const attHtml=a=>(a||[]).map(x=>{
  if(x.kind==='image'&&x.data)return`<img class="th" src="data:${x.mime};base64,${x.data}">`;
  if(x.kind==='video'&&x.frames&&x.frames[0])return`<div class="th vid"><img src="data:image/jpeg;base64,${x.frames[0]}"><i>▶</i></div>`;
  const k=x.k||x.kind;return`<span class="chip">${k==='pdf'?'📄':k==='video'?'🎬':k==='image'?'🖼️':'📎'}<span>${esc(x.name)}</span></span>`}).join('');
function msgHtml(m,i,isNew,last){
  const cls='m '+(m.role==='user'?'u':'a')+(isNew?' new':'');
  if(m.role==='user')return`<div class="${cls}" id="m${i}"><div class="col">${m.att&&m.att.length?`<div class="atts">${attHtml(m.att)}</div>`:''}${m.content?`<div class="b">${esc(m.content)}</div>`:''}</div></div>`;
  const live=S.busy&&last&&!m.err;
  let body;
  if(m.err)body=`<div class="err">${esc(m.err)}${m.code==='auth'||m.code==='model'?`<button class="lnk" data-act="settings">${m.code==='auth'?'Ayarları aç':'Modelleri yenile'}</button>`:''}</div>`;
  else if(!m.content)body='<div class="think"><i></i><i></i><i></i></div>';
  else body=`<div class="md${live?' live':''}">${md(m.content)}</div>`;
  const mt=m.meta?`<span>${esc(m.model||'')}${m.meta.ttft?` · ⚡ ${m.meta.ttft.toFixed(1)}s ilk token`:''} · ${m.meta.ms.toFixed(1)}s</span>`:'';
  const acts=!live&&!m.err&&m.content?`<div class="acts"><button data-act="copy" data-i="${i}">${ic('copy',14)} Kopyala</button>${last?`<button data-act="regen">${ic('ref',14)} Yeniden üret</button>`:''}</div>`:'';
  return`<div class="${cls}" id="m${i}"><div class="av">${logo(m.provider||cur(),20)}</div><div class="col">${body}<div class="meta">${mt}${acts}</div></div></div>`;
}
function renderMsgs(newFrom=1e9){
  const c=S.cur,box=$('#msgs');
  if(!c||!c.messages.length){box.innerHTML=heroHtml();return}
  const n=c.messages.length;
  box.innerHTML='<div class="wrap">'+c.messages.map((m,i)=>msgHtml(m,i,i>=newFrom,i===n-1)).join('')+'</div>';
  scrollEnd(true);
}
function paintMsg(i){
  const m=S.cur.messages[i],el=$('#m'+i+' .col');if(!el)return;
  const stick=atBottom();
  el.querySelector('.think')&&(el.innerHTML=`<div class="md live"></div><div class="meta"></div>`);
  const b=el.querySelector('.md');if(b)b.innerHTML=md(m.content);
  if(stick)scrollEnd(true);
}
function setSendBtn(){const b=$('#send');b.classList.toggle('stop',S.busy);b.innerHTML=S.busy?STOP:ic('up',20);b.title=S.busy?'Durdur':'Gönder'}
function renderChips(){
  $('#chips').innerHTML=S.att.map((a,i)=>{
    const th=a.kind==='busy'?'<div class="ic"><div class="spin"></div></div>':a.kind==='image'?`<img src="data:${a.mime};base64,${a.data}">`:a.kind==='video'?`<img src="data:image/jpeg;base64,${a.frames[0]}">`:`<div class="ic">${a.kind==='pdf'?'📄':'📎'}</div>`;
    const sub=a.kind==='busy'?'hazırlanıyor…':a.kind==='video'?`video · ${Math.round(a.dur)} sn`:a.kind;
    return`<div class="pc">${th}<div style="min-width:0"><span>${esc(a.name)}</span><small>${sub}</small></div><button data-rm="${i}">${ic('x',14)}</button></div>`}).join('');
}

/* ───── ekler (fotoğraf · video · pdf · kod) ───── */
const TEXTEXT=/\.(txt|md|py|js|ts|jsx|tsx|json|csv|tsv|html?|css|xml|ya?ml|log|sql|java|c|h|cpp|cs|go|rs|php|rb|sh|bat|ps1|ini|toml|cfg|env)$/i;
async function imgAtt(f){
  const url=URL.createObjectURL(f);
  const im=await new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>no(new Error('Görsel okunamadı: '+f.name));i.src=url});
  let mime=f.type,data;
  if(/^image\/(png|jpeg|webp|gif)$/.test(f.type)&&f.size<3.5e6&&Math.max(im.width,im.height)<=2000)data=await readB64(f);
  else{const sc=Math.min(1,1800/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*sc);c.height=Math.round(im.height*sc);
    const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(im,0,0,c.width,c.height);data=c.toDataURL('image/jpeg',.86).split(',')[1];mime='image/jpeg'}
  URL.revokeObjectURL(url);return{kind:'image',name:f.name,mime,data};
}
async function vidAtt(f){
  const url=URL.createObjectURL(f),v=document.createElement('video');v.muted=true;v.preload='auto';v.playsInline=true;v.src=url;
  await new Promise((ok,no)=>{v.onloadeddata=ok;v.onerror=()=>no(new Error('Bu video biçimi açılamadı (MP4/H.264 ya da WebM dene)'));setTimeout(()=>no(new Error('Video yüklenemedi (zaman aşımı)')),25000)});
  const dur=v.duration||1,N=dur<8?5:8,frames=[],c=document.createElement('canvas'),sc=Math.min(1,768/Math.max(v.videoWidth,v.videoHeight));
  c.width=Math.round(v.videoWidth*sc);c.height=Math.round(v.videoHeight*sc);const g=c.getContext('2d');
  for(let i=0;i<N;i++){v.currentTime=Math.min(Math.max(dur-.05,0),dur*(i+.5)/N);await new Promise(r=>{v.onseeked=r;setTimeout(r,3000)});g.drawImage(v,0,0,c.width,c.height);frames.push(c.toDataURL('image/jpeg',.72).split(',')[1])}
  URL.revokeObjectURL(url);return{kind:'video',name:f.name,mime:f.type||'video/mp4',file:f,frames,dur,size:f.size};
}
async function addFiles(files){
  for(const f of files){
    const ph={kind:'busy',name:f.name};S.att.push(ph);renderChips();
    try{
      const t=f.type||'';let a;
      if(t.startsWith('image/'))a=await imgAtt(f);
      else if(t.startsWith('video/'))a=await vidAtt(f);
      else if(t==='application/pdf'||/\.pdf$/i.test(f.name)){if(f.size>30e6)throw new Error('PDF en fazla 30 MB olabilir');a={kind:'pdf',name:f.name,data:await readB64(f)}}
      else if(f.size<=1.5e6&&(t.startsWith('text/')||TEXTEXT.test(f.name)||!t))a={kind:'text',name:f.name,text:await f.text()};
      else throw new Error('Desteklenmeyen dosya: '+f.name);
      Object.assign(ph,a);
    }catch(e){S.att=S.att.filter(x=>x!==ph);toast(e.message)}
    renderChips();
  }
}
async function attPayload(list,pid){
  const out=[];
  for(const a of list){
    if(a.kind==='video'){const p={kind:'video',name:a.name,mime:a.mime,frames:a.frames,dur:a.dur};if(pid==='gemini'&&a.size<=14e6)p.data=await readB64(a.file);out.push(p)}
    else out.push({...a});
  }
  return out;
}

/* ───── gönder / akış ───── */
async function send(text,regen){
  if(S.busy)return;
  const st=S.st,pid=cur(),P=PV();
  if(!P.hasKey){toast(`${P.name} için önce API anahtarı ekle`);openSettings(pid);return}
  if(S.att.some(a=>a.kind==='busy')){toast('Ek dosya hâlâ hazırlanıyor…');return}
  const c=S.cur||newChat();
  if(!regen){
    text=(text||'').trim();if(!text&&!S.att.length)return;
    const att=await attPayload(S.att,pid);
    c.messages.push({role:'user',content:text,att});
    if(c.title==='Yeni sohbet')c.title=(text||att[0].name).replace(/\s+/g,' ').slice(0,44);
    S.att=[];renderChips();$('#ta').value='';autosize();
  }
  const am={role:'assistant',content:'',provider:pid,model:P.model};
  c.messages.push(am);c.ts=Date.now();
  S.busy=true;S.ctrl=new AbortController();setSendBtn();renderSide();
  const idx=c.messages.length-1;
  renderMsgs(regen?idx:idx-1);
  const hist=c.messages.slice(0,idx).filter(m=>!m.err&&(m.content||(m.att&&m.att.length))).map((m,k,a)=>({role:m.role,content:m.content,att:(m.att||[]).map(x=>(x.kind==='video'&&k<a.length-1)?{...x,data:undefined}:x)}));
  const t0=performance.now();let first=0,raf=0;
  try{
    const r=await fetch('/api/chat',{method:'POST',signal:S.ctrl.signal,headers:{'X-Nexus-Token':TOKEN,'Content-Type':'application/json'},body:JSON.stringify({provider:pid,model:P.model,messages:hist,system:st.settings.system,temp:st.settings.temp})});
    if(!r.ok||!r.body)throw new Error((await r.json().catch(()=>({}))).error||'Sunucu hatası '+r.status);
    const rd=r.body.getReader(),dec=new TextDecoder();let buf='';
    for(;;){
      const{done,value}=await rd.read();if(done)break;
      buf+=dec.decode(value,{stream:true});let n;
      while((n=buf.indexOf('\n'))>=0){
        const ln=buf.slice(0,n).trim();buf=buf.slice(n+1);if(!ln)continue;
        let ev;try{ev=JSON.parse(ln)}catch{continue}
        if(ev.t){if(!first)first=performance.now();am.content+=ev.t;if(!raf)raf=requestAnimationFrame(()=>{raf=0;paintMsg(idx)})}
        else if(ev.err){am.err=ev.err;am.code=ev.code||''}
      }
    }
  }catch(e){if(e.name!=='AbortError')am.err=/fetch|network/i.test(e.message)?'Yerel sunucuya ulaşılamadı. Uygulamayı kapatıp yeniden aç.':e.message}
  const stopped=S.ctrl&&S.ctrl.signal.aborted;
  S.busy=false;S.ctrl=null;
  if(stopped&&!am.content&&!am.err)c.messages.pop();
  else{if(!am.content&&!am.err)am.err='Yanıt boş döndü — başka bir model dene.';am.meta={ttft:first?(first-t0)/1000:0,ms:(performance.now()-t0)/1000}}
  c.messages.forEach(m=>{if(m.att)m.att.forEach(a=>{if(a.kind==='video')delete a.data})});
  setSendBtn();renderSide();renderMsgs();save(true);
}
function autosize(){const t=$('#ta');t.style.height='auto';t.style.height=Math.min(t.scrollHeight,200)+'px'}

/* ───── ayarlar penceresi ───── */
function renderSettings(focus){
  $('#keys').innerHTML=Object.entries(S.st.providers).map(([id,p])=>`<div class="krow ${id===focus?'focus':''}" data-p="${id}"><div class="kh">${logo(id,22)}<b>${p.name}</b><span class="stat ${p.hasKey?(p.live?'ok':'warn'):''}">${p.hasKey?(p.live?`Bağlı · ${p.models.length} model`:'Kayıtlı · test edilmedi'):'Anahtar yok'}</span><a href="${p.url}" target="_blank" rel="noopener">Anahtar al ↗</a></div>
  <div class="kin"><input type="password" autocomplete="off" spellcheck="false" placeholder="${p.hasKey?esc(p.masked)+'  (değiştirmek için yapıştır)':'API anahtarını yapıştır'}"><button class="ghost eye" title="Göster/gizle">${ic('eye',16)}</button><button class="pri test">Kaydet &amp; test et</button>${p.hasKey?`<button class="ghost del" title="Anahtarı sil">${ic('trash',16)}</button>`:''}</div><div class="kmsg"></div></div>`).join('');
  if(focus){const i=$(`.krow[data-p=${focus}] input`);setTimeout(()=>i&&i.focus(),250)}
}
function openSettings(focus){renderSettings(focus);$('#sys').value=S.st.settings.system;$('#temp').value=S.st.settings.temp;$('#tv').textContent=(+S.st.settings.temp).toFixed(2);$('#modal').classList.add('on')}
const closeSettings=()=>$('#modal').classList.remove('on');
async function testKey(row,remove){
  const id=row.dataset.p,inp=$('input',row),msg=$('.kmsg',row),btn=$('.test',row);
  msg.className='kmsg';msg.textContent='';btn.disabled=true;const old=btn.innerHTML;btn.textContent='Test ediliyor…';
  try{
    const r=await api('/api/key',{provider:id,key:inp.value,remove:!!remove});
    S.st=r.state||S.st;
    if(remove){renderSettings();renderTop();renderMsgs();return}
    if(r.ok){renderSettings(id);renderTop();renderMsgs();const m=$(`.krow[data-p=${id}] .kmsg`);m.className='kmsg good';m.textContent=`✓ Anahtar çalışıyor — ${r.count} model yüklendi.`}
    else{renderSettings(id);const m=$(`.krow[data-p=${id}] .kmsg`);m.className='kmsg bad';m.textContent=r.error}
  }catch(e){msg.className='kmsg bad';msg.textContent=e.message;btn.disabled=false;btn.innerHTML=old}
}

/* ───── olaylar ───── */
function openChat(id){if(S.busy&&S.ctrl)S.ctrl.abort();const c=S.chats.find(x=>x.id===id);if(!c)return;S.cur=c;renderSide();renderMsgs();$('#side').classList.remove('open')}
function startNew(){if(S.busy&&S.ctrl)S.ctrl.abort();if(S.cur&&!S.cur.messages.length){$('#ta').focus();return}newChat();S.att=[];renderAll();$('#ta').focus();$('#side').classList.remove('open')}
function setTheme(t){document.documentElement.dataset.theme=t;S.st.settings.theme=t;$('#themeBtn').innerHTML=ic(t==='dark'?'sun':'moon',17)}
function pickProvider(id){
  if(id===cur())return;
  S.st.settings.provider=id;document.documentElement.dataset.provider=id;saveCfg({provider:id});renderTop();
  if(!S.cur||!S.cur.messages.length)renderMsgs();
  if(!S.st.providers[id].hasKey){toast(`${S.st.providers[id].name} için API anahtarı gerekli`);openSettings(id)}
}
document.addEventListener('click',async e=>{
  const t=e.target;let el;
  if(el=t.closest('#seg button'))return pickProvider(el.dataset.p);
  if(el=t.closest('.item')){const d=t.closest('[data-del]');if(d){const id=d.dataset.del;S.chats=S.chats.filter(c=>c.id!==id);if(S.cur&&S.cur.id===id){S.cur=null;if(S.busy&&S.ctrl)S.ctrl.abort()}renderAll();save(true);return}return openChat(el.dataset.id)}
  if(el=t.closest('.cp')){const code=el.closest('.code').querySelector('code').textContent;try{await navigator.clipboard.writeText(code);el.textContent='Kopyalandı ✓';setTimeout(()=>el.textContent='Kopyala',1400)}catch{toast('Kopyalanamadı')}return}
  if(el=t.closest('[data-act]')){
    const a=el.dataset.act;
    if(a==='settings')return openSettings(cur());
    if(a==='copy'){const m=S.cur.messages[+el.dataset.i];try{await navigator.clipboard.writeText(m.content);toast('Kopyalandı')}catch{toast('Kopyalanamadı')}return}
    if(a==='regen'){const ms=S.cur.messages;while(ms.length&&ms[ms.length-1].role==='assistant')ms.pop();return send(null,true)}
  }
  if(el=t.closest('.card'))return(()=>{const ta=$('#ta');ta.value=el.dataset.q;autosize();ta.focus()})();
  if(el=t.closest('[data-rm]')){S.att.splice(+el.dataset.rm,1);return renderChips()}
  if(el=t.closest('.krow')){
    if(t.closest('.eye')){const i=$('input',el);i.type=i.type==='password'?'text':'password';return}
    if(t.closest('.test'))return testKey(el,false);
    if(t.closest('.del'))return testKey(el,true);
  }
  if(t===$('#modal'))closeSettings();
});
$('#newChat').onclick=startNew;$('#openSet').onclick=()=>openSettings(cur());$('#closeSet').onclick=closeSettings;
$('#menu').onclick=()=>$('#side').classList.toggle('open');
$('#themeBtn').onclick=()=>{const t=S.st.settings.theme==='dark'?'light':'dark';setTheme(t);saveCfg({theme:t})};
$('#attach').onclick=()=>$('#file').click();
$('#file').onchange=e=>{addFiles([...e.target.files]);e.target.value=''};
$('#send').onclick=()=>S.busy?S.ctrl&&S.ctrl.abort():send($('#ta').value);
$('#model').onchange=e=>{PV().model=e.target.value;saveCfg({model:{[cur()]:e.target.value}})};
$('#refresh').onclick=async()=>{const b=$('#refresh');b.style.opacity=.5;try{const r=await api('/api/key',{provider:cur(),key:''});S.st=r.state||S.st;renderTop();renderMsgs();r.ok?toast(`${r.count} model yüklendi`):toast(r.error,7000)}catch(e){toast(e.message)}b.style.opacity=1};
$('#ta').addEventListener('input',autosize);
$('#ta').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();if(!S.busy)send($('#ta').value)}});
$('#ta').addEventListener('paste',e=>{const fs=[...(e.clipboardData?e.clipboardData.files:[])];if(fs.length){e.preventDefault();addFiles(fs)}});
let dragN=0;
addEventListener('dragenter',e=>{if(e.dataTransfer&&[...e.dataTransfer.types].includes('Files')){dragN++;$('#drop').classList.add('on')}});
addEventListener('dragleave',()=>{if(--dragN<=0){dragN=0;$('#drop').classList.remove('on')}});
addEventListener('dragover',e=>e.preventDefault());
addEventListener('drop',e=>{e.preventDefault();dragN=0;$('#drop').classList.remove('on');if(e.dataTransfer.files.length)addFiles([...e.dataTransfer.files])});
addEventListener('keydown',e=>{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();startNew()}
  if((e.ctrlKey||e.metaKey)&&e.key===','){e.preventDefault();openSettings(cur())}
  if(e.key==='Escape')closeSettings();
});
addEventListener('resize',moveInd);
addEventListener('pagehide',()=>navigator.sendBeacon('/api/bye?t='+TOKEN,''));
document.addEventListener('pointermove',e=>{const c=e.target.closest&&e.target.closest('.card');if(c){const r=c.getBoundingClientRect();c.style.setProperty('--mx',(e.clientX-r.left)+'px');c.style.setProperty('--my',(e.clientY-r.top)+'px')}});
let sysT;$('#sys').oninput=e=>{S.st.settings.system=e.target.value;clearTimeout(sysT);sysT=setTimeout(()=>saveCfg({system:e.target.value}),500)};
$('#temp').oninput=e=>{const v=+e.target.value;S.st.settings.temp=v;$('#tv').textContent=v.toFixed(2);clearTimeout(sysT);sysT=setTimeout(()=>saveCfg({temp:v}),400)};

/* ───── başlangıç ───── */
(async function init(){
  $('#brandLogo').innerHTML=BRAND;$('#newChat').innerHTML=ic('plus',18)+' Yeni sohbet';$('#openSet').innerHTML=ic('set',17)+' Ayarlar';
  $('#closeSet').innerHTML=ic('x',16);$('#menu').innerHTML=ic('menu',18);$('#refresh').innerHTML=ic('ref',17);$('#attach').innerHTML=ic('clip',19);
  try{
    const[st,chats]=await Promise.all([api('/api/state'),api('/api/chats')]);
    S.st=st;S.chats=Array.isArray(chats)?chats:[];
  }catch(e){document.body.innerHTML='<p style="padding:40px;font:16px system-ui">Sunucuya bağlanılamadı: '+esc(e.message)+'<br>Uygulamayı kapatıp yeniden aç.</p>';return}
  const s=S.st.settings;
  if(!S.st.providers[s.provider].hasKey){const f=Object.keys(S.st.providers).find(k=>S.st.providers[k].hasKey);if(f)s.provider=f}
  document.documentElement.dataset.provider=s.provider;setTheme(s.theme);
  renderAll();
  if(!Object.values(S.st.providers).some(p=>p.hasKey))setTimeout(()=>openSettings(),600);
  const ping=()=>api('/api/ping',{}).catch(()=>{});ping();setInterval(ping,15000);
  setTimeout(moveInd,300);
})();
</script>
</body>
</html>
"""

if __name__ == "__main__":
    main()
